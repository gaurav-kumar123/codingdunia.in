from django.shortcuts import render

def About(request):
    return render(request,'mainsite/about.html')
def homePage(request):
    return render(request,'mainsite/home.html')

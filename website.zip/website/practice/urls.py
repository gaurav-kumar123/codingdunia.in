from django.urls import path
from . import views
urlpatterns = [
    
    path('practice/',views.practice,name='practice'),
    path('basicex/',views.basic,name='basic'),
    path('listex/',views.listex,name='list'),
    path('stringex/',views.stringex,name='string'),
    path('tupleex/',views.tupleex,name='tuple'),
    path('setex/',views.setex,name='set'),
    path('dictex/',views.dictex,name='dict')
]

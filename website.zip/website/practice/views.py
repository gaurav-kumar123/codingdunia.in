from django.shortcuts import render

def practice(request):
    return render(request,'practice/practice.html')

def basic(request):
    return render(request,'practice/basicex.html')

def listex(request):
    return render(request,'practice/listex.html')

def stringex(request):
    return render(request,'practice/stringex.html')

def tupleex(request):
    return render(request,'practice/tupleex.html')

def setex(request):
    return render(request,'practice/setex.html')

def dictex(request):
    return render(request,'practice/dictex.html')